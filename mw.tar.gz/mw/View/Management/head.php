<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Multiweld Engg. Pvt Limited</title>

    <!-- Bootstrap Core CSS -->
    <link href="../css/boot_css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../css/boot_css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="../css/boot_css/plugins/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/boot_css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../css/boot_css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../css/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <script type='text/javascript' src='../js/jquery.js'></script>
    <script type='text/javascript' src='../js/jquery.min.js'></script>
    
    <link rel="stylesheet" type="text/css" href="../js/css/jquery.datetimepicker.css"/>
    
    <script type='text/javascript' src='../js/ang_js/angular.js'></script>
    
</head>
