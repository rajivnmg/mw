<?php
$name='Dhyana-Regular';
$type='TTF';
$desc=array (
  'CapHeight' => 771,
  'XHeight' => 571,
  'FontBBox' => '[-672 -374 1304 1239]',
  'Flags' => 4,
  'Ascent' => 1239,
  'Descent' => -374,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 256,
);
$unitsPerEm=2048;
$up=-104;
$ut=23;
$strp=250;
$strs=50;
$ttffile='D:/wamp/www/multiGurgaonNew/pdf/mpdf60/ttfonts/Dhyana-Regular.ttf';
$TTCfontID='0';
$originalsize=72348;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='dhyana';
$panose=' 0 0 2 0 8 3 5 0 0 2 0 4';
$haskerninfo=false;
$haskernGPOS=true;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 1239, -374, 0
// usWinAscent/usWinDescent = 1239, -374
// hhea Ascent/Descent/LineGap = 1239, -374, 0
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'lao ' => 'DFLT ',
  'latn' => 'DFLT ',
);
$GSUBFeatures=array (
  'lao ' => 
  array (
    'DFLT' => 
    array (
      'liga' => 
      array (
        0 => 0,
        1 => 1,
      ),
      'ccmp' => 
      array (
        0 => 2,
      ),
    ),
  ),
  'latn' => 
  array (
    'DFLT' => 
    array (
      'liga' => 
      array (
        0 => 0,
        1 => 1,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 8766,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 8778,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 9092,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'DFLT' => 'DFLT ',
  'lao ' => 'DFLT ',
  'latn' => 'DFLT ',
);
$GPOSFeatures=array (
  'DFLT' => 
  array (
    'DFLT' => 
    array (
      'kern' => 
      array (
        0 => 0,
        1 => 1,
      ),
    ),
  ),
  'latn' => 
  array (
    'DFLT' => 
    array (
      'kern' => 
      array (
        0 => 0,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 496,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 2868,
      1 => 4756,
    ),
    'MarkFilteringSet' => '',
  ),
);
?>