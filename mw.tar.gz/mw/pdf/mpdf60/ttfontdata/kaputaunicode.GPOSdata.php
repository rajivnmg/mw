<?php
$LuCoverage = array (
  0 => 
  array (
    0 => 
    array (
      3530 => 0,
      3538 => 1,
      3539 => 2,
    ),
  ),
  1 => 
  array (
    0 => 
    array (
      3540 => 0,
      3542 => 1,
    ),
  ),
);
?>