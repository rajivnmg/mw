<style>@page{
     margin: 40px;
}</style>
<div class="imagedrive" style="margin: 36px; margin: auto; width: 576px; height: 576px; overflow: hidden;">
	<div class="double" style="overflow: hidden;">
    	
		<div class="common" style="padding: 0; width: 234px; float: left; height: 504px; border:1px solid #ooo; margin-top:36px;">
			<div class="img" style="text-align:center;">
				<img src="http://192.168.1.93/mpdf60/examples/img_234x576.jpg" alt="" />
			</div>
		</div>
		
		<div class="double" style="width: 234px; height: 504px; float: right;">
			<div class="common" style="padding: 0; position: relative; width: 234px; height: 234px; border:1px solid #ooo; ">
				<img src="http://192.168.1.93/mpdf60/examples/img220x175.jpg" alt="" />
			</div>
			<div class="common" style="padding: 0; margin-top: 36px; position: relative; width: 234px; height: 234px; border:1px solid #ooo; ">
				<img src="http://192.168.1.93/mpdf60/examples/img220x175.jpg" alt="" />
			</div>
		</div>
		
    </div>
</div>
