<?php
$res = file_get_contents("http://52.38.190.17/mw/email.php?SITENAME=HARIDWAR");
echo $res;
