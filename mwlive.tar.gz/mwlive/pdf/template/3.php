<style>@page{
     margin: 36px;
     width: 576px;
     height: 576px;
}</style>
<div class="imagedrive">
	<div class="double">
		<div class="img" style="width: 504px; height: 234px; text-align:center;">
			<img src="http://localhost/image_pdf/images/images-7.jpg" alt="" style="height: 234px;" />
		</div>
        <div class="common" style=" width: 504px; height: 234px; text-align:center; margin-top: 36px;">
            <img src="http://localhost/image_pdf/images/images-7.jpg" alt="" style="height: 234px;"/>
        </div>
    </div>
</div>
