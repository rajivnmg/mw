<?php 
$originalsize=86052;
?>